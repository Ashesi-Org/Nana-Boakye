import 'package:flutter/material.dart';
import 'package:webtech_project/constants.dart';
import 'customText.dart';


class CustomAppbar extends StatefulWidget implements PreferredSizeWidget{
  final String title;
  final bool iscentered;
  final Color color;
  final VoidCallback? onbacktapped;
  
  const CustomAppbar({
    super.key,
    this.color = kPrimary,
    this.iscentered = false,
    this.onbacktapped,
    required this.title
    });

  @override
  State<CustomAppbar> createState() => _CustomAppbarState();
  
  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(50);
}

class _CustomAppbarState extends State<CustomAppbar> {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: widget.color,
      title: CustomText(
        text: widget.title,
        isbold: true,
      ),
      centerTitle: widget.iscentered,
      leading: widget.onbacktapped !=null ? IconButton(
        onPressed: widget.onbacktapped,
        icon: const Icon(Icons.arrow_back, color: kBlack,)): const SizedBox.shrink(),

    );
  }
}