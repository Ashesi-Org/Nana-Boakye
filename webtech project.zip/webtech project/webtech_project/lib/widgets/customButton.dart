import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter/material.dart';
import 'package:webtech_project/constants.dart';
import 'package:webtech_project/widgets/customText.dart';



class CustomButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String text;
  final double height;
  final double? width;

  const CustomButton({
    super.key,
    this.width,
    required this.text,
    this.height = 56.0,
    required this.onPressed
    });

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return  SizedBox(
      width: widget.width,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          fixedSize: Size.fromHeight(widget.height),
          backgroundColor: kPrimary
        ),
        onPressed: widget.onPressed,
        child: CustomText(
          text: widget.text,
          color: kWhite,
        ),
      ),
    );
  }
}