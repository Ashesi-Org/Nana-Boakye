import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:webtech_project/constants.dart';

class CustomText extends StatelessWidget {
  final String text;
  final bool isbold;
  final double fontSize;
  final Color color;
  

  const CustomText({super.key,
    required this.text,
    this.isbold = false,
    this.fontSize = 14,
    this.color = kBlack

  });

  @override
  Widget build(BuildContext context) {
    return  Text(
      text,
      style: GoogleFonts.manrope(
        fontWeight: isbold? kBold:FontWeight.w400,
        fontSize: fontSize,
        color: color
         
      ),);
  }
}