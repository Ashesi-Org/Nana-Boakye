import 'package:flutter/material.dart';
import 'package:webtech_project/mainScreens/feedPage.dart';
import 'package:webtech_project/mainScreens/profileViewPage.dart';
import 'constants.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

final PageController _pageViewController = PageController();
int index = 0;

  List<Widget> mainScreens = [
    ProfileViewPage(),
    FeedPage()
  ];
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index){
          _pageViewController.jumpToPage(index);
          setState(() {
            this.index = index;
          });
        },
        items: [
          BottomNavigationBarItem(
          
            icon: Icon(Icons.person, color: index == 0? kPrimary: kGrey,),
            ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: index == 1? kPrimary: kGrey,))
        ],
        type: BottomNavigationBarType.fixed,
      ),
      body: PageView(
        controller: _pageViewController,
        onPageChanged: (index){
          setState(() {
            this.index = index;
          });
        },
        children: mainScreens,)

    );
  }
}
