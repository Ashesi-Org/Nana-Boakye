import 'package:flutter/material.dart';
import 'package:webtech_project/homeScreen.dart';
import 'package:webtech_project/widgets/customAppBar.dart';
import 'package:webtech_project/widgets/customText.dart';
import 'package:webtech_project/widgets/customTextField.dart';
import 'package:webtech_project/widgets/customButton.dart';


class CreateProfileAccount extends StatefulWidget {
  const CreateProfileAccount({super.key});

  @override
  State<CreateProfileAccount> createState() => _CreateProfileAccountState();
}

class _CreateProfileAccountState extends State<CreateProfileAccount> {

  String dropDownValue= '';
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: const CustomAppbar(
        title: 'Create Your Account',
        iscentered: true,

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomTextField(
              labelText: 'Name',

            ),
            CustomTextField(
              labelText: 'Email',
            ),
            CustomTextField(
              labelText: 'Student ID',
            ),

            // Create Date picker for date of birth
            // CustomTextField(
            //   labelText: ,
            // )

            DropdownButton(
              hint: const CustomText( 
                text: 'Are you a campus resident?'),
              items: const[
              DropdownMenuItem(
                value: 'True',
                child: CustomText(
                text: 'True')),
              DropdownMenuItem(
                value: 'False',
                child: CustomText(
                text: 'False',
              ))
            ],
            isExpanded: true,
            onChanged: (value){
              setState(() {
                dropDownValue = value.toString();
              });
            },
            
            
            ),
            CustomTextField(
              labelText: 'Your favourite movie',
            ),
            CustomTextField(
              labelText: 'Your favourite food',
            ),

            CustomButton(
              text: 'Create Account',
              onPressed: (){
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context)=> HomeScreen()), (route) => false);
              },
            )
          ],
        ),
      ),
    );
  }
}