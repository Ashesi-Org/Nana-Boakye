import 'package:flutter/material.dart';
import 'package:webtech_project/homeScreen.dart';
import 'package:webtech_project/widgets/customAppBar.dart';
import 'package:webtech_project/widgets/customText.dart';
import 'package:webtech_project/widgets/customTextField.dart';
import 'package:webtech_project/widgets/customButton.dart';


class CreateProfileAccount extends StatefulWidget {
  const CreateProfileAccount({super.key});

  @override
  State<CreateProfileAccount> createState() => _CreateProfileAccountState();
}

class _CreateProfileAccountState extends State<CreateProfileAccount> {

  String dropDownValue= '';
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: const CustomAppbar(
        title: 'Login To Your Account',
        iscentered: true,

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
       
            CustomTextField(
              labelText: 'Email',
            ),
            CustomTextField(
              labelText: 'Student ID',
            ),

            CustomButton(
              text: 'Log In',
              onPressed: (){
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (context)=> HomeScreen()), (route) => false);
              },
            )
          ],
        ),
      ),
    );
  }
}