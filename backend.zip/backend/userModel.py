class UserModel:
    def __init__(self, userID, phoneNumber, email, dateOfBirth, yearGroup,campusResidence,favFood,favMovie ):
        self.userID = userID,
        self.phoneNumber = phoneNumber,
        self.email = email,
        self.dateOfBirth= dateOfBirth,
        self.yearGroup = yearGroup,
        self.campusResidence = campusResidence,
        self.favFood = favFood,
        self.favMovie = favMovie

    def to_dict(self):
        return {
            'userId': self.userID,
            'phoneNumber': self.phoneNumber,
            'email': self.email,
            'dateOfBirth': self.dateOfBirth,
            'yearGroup': self.yearGroup,
            'campusResidence': self.campusResidence,
            'favFood': self.favFood,
            'favMovie': self.favMovie
        }
    

