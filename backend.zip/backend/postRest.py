from flask import Flask, jsonify, request
import firebase_admin
from firebase_admin import credentials, firestore
from postModel import PostModel


# initialise firebase
cred = credentials.Certificate('social-project-144e7-firebase-adminsdk-v85r4-8f4d33c2d5.json')
firebase_admin.initialize_app(cred)

db = firestore.client()

# -------------- FIREBASE REFERENCES -----------------
postRef = db.collection('Posts')



app = Flask(__name__)

# create post code
# Post Details needed:
# id, email, message, email, timestamp

@app.route('/Posts', methods=['POST'])
def createPost():
    userEmail = request.json['email']
    data = request.json
    postID = request.json['']

    # if user does not exist create new user
    try:
        # create post in firestore
        postRef.doc().set(data)m
        return jsonify({'post created;'}), 201

    except: 
        return jsonify({'message': 'Something went wrong'}), 404,



# Get all post details 
@app.route('/Posts', methods=['GET'])
def getPostDetails():
    data = request.json
    posts = postRef.get()
  
    posts = [doc.to_dict() for doc in posts]
    return jsonify(posts), 201



# Get post details 
@app.route('/Posts/<userEmail>', methods=['GET'])
def getUserPostDetails(userEmail):
    data = request.json
    # get user account and check whether it exists
    postRef = postRef.where('userEmail', '==', userEmail).stream()

    # posts = PostModel(
    #         userID=data['userID'],
    #         message= data['message'],
    #         timeStamp=data['timeStamp'],
    #         UserEmail=data['UserEmail'],
       
    #     )
    postInfo = post.to_dict()
    return jsonify(postInfo), 201


# delete user post
@app.route('/Users/<userEmail>', methods=['PUT'])
def updateUserDetails(userEmail):
    userAccount = userRef.doc(userEmail).get()
    
    # collect user data
    data = request.json

    # Update user in firestore 
    try : 
        userAccount.update(data)
        return jsonify({'Updated Successfully'}), 201

    except:
        return jsonify({'message':'An error occured during update'})


if __name__ == '__main__':
    app.run()
