class PostModel:
    def __init__(
        self, 
        message, 
        userEmail,
        userID, 
        timestamp):


        self.userID = userID,
        self.message = message,
        self.userEmail = userEmail,
        self.timestamp =timestamp

    def to_dict(self):
        return {
            'userId': self.userID,
            'message': self.phoneNumber,
            'userEmail': self.email,
            'timeStamp': self.timeStamp,
        }
    

