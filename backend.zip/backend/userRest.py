from flask import Flask, jsonify, request
import firebase_admin
from firebase_admin import credentials, firestore

from userModel import UserModel


# initialise firebase
cred = credentials.Certificate('social-project-144e7-firebase-adminsdk-v85r4-8f4d33c2d5.json')
firebase_admin.initialize_app(cred)

db = firestore.client()

# -------------- FIREBASE REFERENCES -----------------
userRef = db.collection('Users')
postRef = db.collection('Posts')



app = Flask(__name__)

# create user code
# User Details needed:
# id, number, name, email, dob, year group, major, campus residence?, best food, best movie


@app.route('/Users', methods=['POST'])
def createUser():
    userEmail = request.json['email']
    userAccount = userRef.doc(userEmail).get()
    data = request.json
    # check if user exists
    if userAccount.exists():
        return jsonify({'message':'User Already exists'}), 404


    # if user does not exist create new user
    try:
        # create user in firestore
        userRef.doc(userEmail).set(data)
        return jsonify({'user': 'user created'}), 201

    except: 
        return jsonify({'message': 'Something went wrong'}), 404,



# Get user details 
@app.route('/Users/<userEmail>', methods=['GET'])
def getUserDetails(userEmail):
    data = request.json
    # get user account and check whether it exists
    userAccount = userRef.doc(userEmail).get()
    if not userAccount.exists():
        return jsonify({'message':'Account does not exist'}), 404
    
    # if user exists return their details
    user = UserModel(
            userID=data['userID'],
            phoneNumber= data['phoneNumber'],
            dateOfBirth=data['dateOfBirth'],
            email=data['email'],
            yearGroup=data['yearGroup'],
            campusResidence=data['campusResidence'],
            favFood=data['favFood'],
            favMovie=data['favMovie']
        )
    userInfo = user.to_dict()
    return jsonify(userInfo), 201


# update user details
@app.route('/Users/<userEmail>', methods=['PUT'])
def updateUserDetails(userEmail):
    userAccount = userRef.doc(userEmail).get()
    
    # collect user data
    data = request.json

    # Update user in firestore 
    try : 
        userAccount.update(data)
        return jsonify({'Updated Successfully'}), 201

    except:
        return jsonify({'message':'An error occured during update'})


if __name__ == '__main__':
    app.run()
