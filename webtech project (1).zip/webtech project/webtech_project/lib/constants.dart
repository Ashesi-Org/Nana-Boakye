import 'package:flutter/material.dart';



// these are the constant colors throughout the application
const Color kBlack = Colors.black;
const Color kWhite = Colors.white;
const Color kError = Colors.red;
const Color kPrimary = Colors.blue;
const Color kGrey = Colors.grey;



// TextStyles
const kBold = FontWeight.w700;